// Telegram Bot webhook handler
// Register this URL with Telegram via:
//   POST https://api.telegram.org/bot<TOKEN>/setWebhook
//   Body: { "url": "https://your-domain.com/api/notify/telegram-webhook" }
//
// Telegram supports a secret_token on webhook registration. NIRDHOOM requires
// that secret so arbitrary callers cannot inject fake farmer updates.

declare const process: { env: Record<string, string | undefined> };

export async function GET(_request: Request) {
  // Telegram does not do a GET verification challenge (unlike WhatsApp).
  // Return a simple confirmation so health checks pass.
  return Response.json({ ok: true, service: 'NIRDHOOM Telegram webhook' }, { status: 200 });
}

export async function POST(request: Request) {
  const secretToken = process.env.TELEGRAM_WEBHOOK_SECRET;
  if (!secretToken) {
    return Response.json({ error: 'Telegram webhook secret is not configured' }, { status: 503 });
  }
  const incoming = request.headers.get('x-telegram-bot-api-secret-token') || '';
  if (!incoming || incoming !== secretToken) {
    return Response.json({ error: 'Invalid webhook secret' }, { status: 401 });
  }

  let update: any;
  try {
    update = await request.json();
  } catch {
    return Response.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  // Extract key fields from the Telegram Update object
  const message = update?.message ?? update?.edited_message ?? null;
  const callbackQuery = update?.callback_query ?? null;

  const processedIds: number[] = [];

  if (message?.message_id) {
    processedIds.push(Number(message.message_id));

    // Structured metadata for downstream logging / Supabase ingestion
    const _event = {
      update_id: update.update_id,
      message_id: message.message_id,
      chat_id: message.chat?.id ?? null,
      chat_type: message.chat?.type ?? null,
      from_user_id: message.from?.id ?? null,
      text: typeof message.text === 'string' ? message.text : null,
      date: message.date ?? null,
    };

    // TODO: persist _event to Supabase telegram_messages table or route to
    // the relevant farmer record based on chat_id ↔ farmer_id mapping.
  }

  if (callbackQuery?.id) {
    // Inline keyboard button press — acknowledge it
    const _cbEvent = {
      update_id: update.update_id,
      callback_query_id: callbackQuery.id,
      chat_id: callbackQuery.message?.chat?.id ?? null,
      data: callbackQuery.data ?? null,
      from_user_id: callbackQuery.from?.id ?? null,
    };

    // TODO: answer the callback_query via answerCallbackQuery if needed.
  }

  // Always return 200 quickly — Telegram will retry if it doesn't get 2xx
  return Response.json({ received: true, update_id: update?.update_id ?? null, processed_message_ids: processedIds }, { status: 200 });
}
