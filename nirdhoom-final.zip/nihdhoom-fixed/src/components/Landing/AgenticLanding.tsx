import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Sparkles, 
  Globe, 
  Box, 
  Map, 
  MessageSquare, 
  Smartphone, 
  Satellite, 
  TrendingUp, 
  Leaf, 
  UserCheck, 
  HelpCircle, 
  ArrowRight, 
  ShieldCheck, 
  Zap, 
  Truck, 
  CheckCircle2, 
  ChevronRight,
  Flame,
  Award,
  Play
} from 'lucide-react';
import { Spotlight } from '../Animated/Spotlight';
import { Marquee } from '../Animated/Marquee';
import { AnimatedBeam } from '../Animated/AnimatedBeam';
import { BentoGrid } from '../Animated/BentoGrid';
import { LiveKPIDashboard } from '../LiveKPIDashboard';
import { ImpactStats } from './ImpactStats';
import { ActiveTab } from '../Header';

interface AgenticLandingProps {
  onNavigateTab: (tab: ActiveTab) => void;
  openBrief: () => void;
  acresScheduled?: number;
  totalPayoutInr?: number;
  co2Avoided?: number;
  firmsZeroBurnCount?: number;
  activeMachines?: number;
  fireEventsOutsideCount?: number;
}

const ROTATING_WORDS = [
  'Agentic Multi-Agent AI',
  'Parametric Slot Guarantees',
  'OR-Tools Constrained VRP',
  'NASA VIIRS 375m Satellite Proof',
  '<90s Instant UPI Disbursements',
  'Institutional Carbon Credits',
];

const PUNJAB_DISTRICT_TICKERS = [
  { district: 'Sangrur (Bhawanigarh)', status: 'ACTIVE DISPATCH', balers: '4 CHC Balers', acres: '88.4 ac', firms: '0 Burns Verified', time: 'Live' },
  { district: 'Patiala (Nabaha)', status: 'VRP RE-ROUTING', balers: '6 CHC Balers', acres: '142.0 ac', firms: '0 Burns Verified', time: '1m ago' },
  { district: 'Barnala (Mehal Kalan)', status: 'HARVEST SPIKE', balers: '3 CHC Balers', acres: '64.8 ac', firms: '0 Burns Verified', time: '2m ago' },
  { district: 'Mansa (Budhlada)', status: 'NDVI 96% MATURE', balers: '5 CHC Balers', acres: '110.5 ac', firms: '0 Burns Verified', time: '3m ago' },
  { district: 'Ludhiana (Jagraon)', status: 'AUCTION CLOSED', balers: '4 CHC Balers', acres: '92.0 ac', firms: '0 Burns Verified', time: '5m ago' },
  { district: 'Bathinda (Rampura)', status: 'SLOT CONTRACTED', balers: '3 CHC Balers', acres: '78.2 ac', firms: '0 Burns Verified', time: '7m ago' },
];

export const AgenticLanding: React.FC<AgenticLandingProps> = ({
  onNavigateTab,
  openBrief,
  acresScheduled = 88.4,
  totalPayoutInr = 128150,
  co2Avoided = 72.6,
  firmsZeroBurnCount = 5,
  activeMachines = 4,
  fireEventsOutsideCount = 8,
}) => {
  const [wordIndex, setWordIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setWordIndex((prev) => (prev + 1) % ROTATING_WORDS.length);
    }, 2800);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex flex-col gap-16 sm:gap-20">
      {/* HERO SECTION WITH SPOTLIGHT & AGENTIC STYLING */}
      <section
        className="relative overflow-hidden px-6 py-20 sm:px-10 sm:py-24 lg:py-28"
        style={{
          background: 'var(--panel-grad)',
          border: '1px solid var(--line)',
          borderRadius: 'var(--radius)',
          boxShadow: 'var(--elev-2)',
        }}
      >
        {/* Aceternity Conic Spotlight */}
        <div className="grid-bg" />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-1/3 left-1/2 h-[560px] w-[860px] -translate-x-1/2 rounded-full"
          style={{
            background: 'radial-gradient(closest-side, color-mix(in srgb, var(--blue-bright) 13%, transparent), transparent)',
          }}
        />

        <div className="relative z-10 mx-auto flex w-full max-w-4xl flex-col items-center text-center">
          {/* Top Pill / Badge with animated radar dot */}
          <div className="badge mb-7" style={{ color: 'var(--blue-bright)', borderColor: 'var(--line-strong)' }}>
            <span className="badge--dot" />
            Punjab CRM dispatch and verification network
          </div>

          {/* Main Kinetic Headline */}
          <h1 className="mx-auto mb-8 max-w-[15ch] text-[2.05rem] leading-[1.04] sm:max-w-[26ch] sm:text-[2.9rem] lg:max-w-[28ch] lg:text-[3.15rem]">
            We don't buy balers. We route Punjab's idle machines with{' '}
            <span className="hero-word" style={{ color: 'var(--blue-bright)' }}>
              {ROTATING_WORDS[wordIndex]}
            </span>
          </h1>

          {/* Hard-hitting subtitle based on the 1-liner brief */}
          <p
            className="mx-auto mb-11 text-[15px] leading-[1.7] sm:text-[17px]"
            style={{ color: 'var(--muted)', maxWidth: '58ch' }}
          >
            Farmers get a <strong style={{ color: 'var(--text)', fontWeight: 600 }}>guaranteed clearance date
            backed by a penalty we pay</strong>, priced by how early they book and settled per acre in under
            ninety seconds over UPI. Every cleared field is checked against NASA FIRMS satellite fire data, so
            the non-burn record is sellable to carbon registries and CBG plants.
          </p>

          {/* Interactive CTAs Bar */}
          <div className="mb-14 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => onNavigateTab('WALKTHROUGH')}
              className="btn-primary flex cursor-pointer items-center gap-2.5"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>Run the live demo</span>
            </button>

            <button
              onClick={() => onNavigateTab('AGENTIC_CONSOLE')}
              className="px-6 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-emerald-400 hover:text-cyan-200 border border-cyan-500/40 font-bold text-sm flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-500/10 hover:scale-[1.02] transition-all"
            >
              <Bot className="w-4 h-4 text-emerald-400 animate-pulse" />
              <span>Agentic Swarm Console</span>
            </button>

            <button
              onClick={() => onNavigateTab('DIGITAL_TWIN_3D')}
              className="btn-secondary flex cursor-pointer items-center gap-2"
            >
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>3D Digital Twin</span>
            </button>

            <button
              onClick={openBrief}
              className="btn-secondary flex cursor-pointer items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Product brief</span>
            </button>
          </div>

          {/* Quick Metrics Bar in Hero with subtle borders */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full max-w-4xl">
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-center hover:border-emerald-500/40 transition-colors">
              <div className="text-xl sm:text-2xl font-black font-mono text-emerald-400">88.4 ac</div>
              <div className="text-[11px] font-mono text-slate-400 mt-1 uppercase">Scheduled Sangrur</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-center hover:border-cyan-500/40 transition-colors">
              <div className="text-xl sm:text-2xl font-black font-mono text-emerald-400">0 Burns</div>
              <div className="text-[11px] font-mono text-slate-400 mt-1 uppercase">NASA FIRMS Verified</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-center hover:border-amber-500/40 transition-colors">
              <div className="text-xl sm:text-2xl font-black font-mono text-amber-400">&lt;90s</div>
              <div className="text-[11px] font-mono text-slate-400 mt-1 uppercase">Instant UPI SLA</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 text-center hover:border-teal-500/40 transition-colors">
              <div className="text-xl sm:text-2xl font-black font-mono text-emerald-400">₹0 Capex</div>
              <div className="text-[11px] font-mono text-slate-400 mt-1 uppercase">Idle CRM Fleet</div>
            </div>
          </div>
        </div>

        {/* Real Ground Reality Visual Showcase: Farmer Hero & Verification */}
        <div className="relative z-10 mt-10 grid grid-cols-1 lg:grid-cols-12 gap-4 max-w-6xl mx-auto">
          {/* Main Visual: Punjab Farmer & Real Field Baler */}
          <div className="lg:col-span-7 rounded-2xl overflow-hidden border border-emerald-500/30 relative group bg-slate-950">
            <img 
              src="/images/punjab_farmer_hero.jpg" 
              alt="Punjabi Farmer in Sangrur Field using Nirdhoom Dispatch"
              className="w-full h-72 sm:h-80 object-cover object-center group-hover:scale-105 transition-transform duration-500"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4">
              <div className="flex items-center gap-2 mb-1.5">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/30 text-emerald-300 border border-emerald-500/50">
                  GROUND REALITY: SANGRUR CLUSTER
                </span>
                <span className="text-xs text-slate-400 font-mono">18 Days Pre-Harvest</span>
              </div>
              <h4 className="text-base sm:text-lg font-bold text-white font-['Outfit']">
                "Reliability beats rate. Every single time."
              </h4>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                Gurpreet Singh Brar (Ubhawal, Sangrur) booked pickup 18 days prior to harvest. Contracted clearance slot locked under ₹4,500 default penalty guarantee; baler dispatched from Bhawanigarh CHC in 90 seconds.
              </p>
            </div>
          </div>

          {/* Secondary Visual: NASA FIRMS 375m Satellite Confirmation */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            <div className="rounded-2xl overflow-hidden border border-cyan-500/30 relative group bg-slate-950 flex-1">
              <img 
                src="/images/satellite_firms.jpg" 
                alt="NASA FIRMS Satellite Thermal Observation of Punjab Indo-Gangetic Plains"
                className="w-full h-40 sm:h-44 object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute bottom-3 left-3 right-3">
                <div className="flex items-center justify-between text-[10px] font-mono text-emerald-400 mb-1">
                  <span>NASA FIRMS VIIRS 375m SENSOR</span>
                  <span className="text-emerald-400 font-bold">0 Burns In Polygon</span>
                </div>
                <div className="text-xs font-bold text-white">
                  Audit Proof Against 100+ Regional Fires
                </div>
              </div>
            </div>

            <div className="rounded-2xl overflow-hidden border border-amber-500/30 relative group bg-slate-950 flex-1">
              <img 
                src="/images/baling_fleet.jpg" 
                alt="Subsidised CRM Baler Fleet Active in Sangrur Fields"
                className="w-full h-32 sm:h-36 object-cover object-center group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute bottom-2.5 left-3 right-3">
                <div className="flex items-center justify-between text-[10px] font-mono text-amber-300 mb-0.5">
                  <span>STRANDED PUBLIC CRM INFRASTRUCTURE</span>
                  <span className="text-emerald-400 font-bold">50-80% Subsidised</span>
                </div>
                <div className="text-xs font-bold text-white">
                  Dispatching Idle CHC &amp; FPO Fleet with Zero Startup Capex
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width Interactive 3D Geospatial Digital Twin Banner */}
        <div 
          onClick={() => onNavigateTab('DIGITAL_TWIN_3D')}
          className="relative z-10 mt-4 rounded-2xl overflow-hidden border border-emerald-500/40 group bg-gradient-to-r from-emerald-950/70 via-slate-900/90 to-teal-950/70 p-4 max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 cursor-pointer hover:border-emerald-400 transition-all shadow-xl hover:shadow-emerald-500/20"
        >
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-500 to-cyan-400 p-0.5 shrink-0 flex items-center justify-center shadow-lg shadow-emerald-500/30">
              <div className="w-full h-full bg-[#03060f] rounded-[10px] flex items-center justify-center">
                <Globe className="w-6 h-6 text-emerald-400 group-hover:scale-110 group-hover:rotate-12 transition-transform duration-300" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold text-white font-['Outfit']">
                  Interactive 3D Geospatial Digital Twin
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold border border-emerald-500/40">
                  Three.js WebGL
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">
                Orbiting NOAA-20 satellite with active radar scan cone, real-time thermal fire anomalies, and 3D verified field beacons across Sangrur.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <span className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-600/30">
              <span>Launch 3D Twin</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
        </div>
      </section>

      {/* INFINITE MARQUEE TELEMETRY TICKER */}
      <section className="relative overflow-hidden rounded-2xl bg-slate-950/90 border border-slate-800 py-2.5 shadow-xl">
        <div className="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-[#03060f] to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-[#03060f] to-transparent z-10 pointer-events-none" />

        <Marquee speed={28} pauseOnHover={true}>
          {PUNJAB_DISTRICT_TICKERS.map((t, idx) => (
            <div
              key={idx}
              className="flex items-center gap-3 px-4 py-1.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs font-mono shrink-0 hover:border-emerald-500/40 transition-colors"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              <span className="font-bold text-white">{t.district}</span>
              <span className="text-slate-600">|</span>
              <span className="text-emerald-400 font-semibold">{t.status}</span>
              <span className="text-slate-600">|</span>
              <span className="text-emerald-400">{t.balers}</span>
              <span className="text-slate-600">|</span>
              <span className="text-amber-300">{t.acres}</span>
              <span className="text-slate-600">|</span>
              <span className="text-slate-400">{t.firms}</span>
            </div>
          ))}
        </Marquee>
      </section>

      {/* SECTION 2: LIVE TELEMETRY DASHBOARD */}
      <section>
        <LiveKPIDashboard
          acresScheduled={acresScheduled}
          totalPayoutInr={totalPayoutInr}
          co2Avoided={co2Avoided}
          firmsZeroBurnCount={firmsZeroBurnCount}
          activeMachines={activeMachines}
          fireEventsOutsideCount={fireEventsOutsideCount}
        />
      </section>

      {/* SECTION 2.5: IMPACT STATISTICS, FARMER TESTIMONIALS & CIRCULAR ECONOMY */}
      <section>
        <ImpactStats onNavigateTab={(tab) => onNavigateTab(tab as ActiveTab)} />
      </section>

      {/* SECTION 3: AUTONOMOUS AGENTIC PIPELINE (ANIMATED BEAM) */}
      <section>
        <AnimatedBeam onSelectNode={(id) => {
          if (id === 'farmer') onNavigateTab('FARMER_SURFACE');
          else if (id === 'vrp') onNavigateTab('OPS_CONSOLE');
          else if (id === 'baler') onNavigateTab('BALER_OPERATOR');
          else if (id === 'nasa') onNavigateTab('SATELLITE_AUDIT');
          else if (id === 'carbon') onNavigateTab('CARBON_MARKET');
          else onNavigateTab('AGENTIC_CONSOLE');
        }} />
      </section>


      {/* SECTION 4: THE 5 STRATEGIC WEDGES (BENTO GRID) */}
      <section>
        <BentoGrid onNavigateTab={(tab) => onNavigateTab(tab as ActiveTab)} />
      </section>

      {/* SECTION 4.5: REAL GROUND DATA, FARMER VOICES & CAQM SATELLITE AUDITS */}
      <ImpactStats />

      {/* SECTION 5: 1-CLICK OPERATIONAL SURFACES CATALOGUE */}
      <section className="rounded-3xl border border-slate-800 bg-slate-950/70 p-6 sm:p-8 backdrop-blur-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-mono uppercase tracking-wider text-emerald-400 font-bold">
                Complete System Architecture
              </span>
            </div>
            <h3 className="text-xl font-bold text-white font-['Outfit'] mt-1">
              Explore All 10 Operational Surfaces
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Section 06 of Brief: "Six personas. We must not build six apps." Ops console is our real product; field surfaces are streamlined thin PWAs and WhatsApp IVR bots.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onNavigateTab('WALKTHROUGH')}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold font-mono transition-all flex items-center gap-1.5 cursor-pointer shadow"
            >
              <span>Guided walkthrough</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            {
              tab: 'AGENTIC_CONSOLE' as ActiveTab,
              title: '🤖 Agentic Swarm Console',
              desc: 'Autonomous 5-agent coordination with 3D Holographic Neural Core, OR-Tools VRP and prompt execution.',
              tag: 'Agentic AI',
              badgeColor: 'text-emerald-400 bg-cyan-950/60 border-cyan-500/30',
            },
            {
              tab: 'WALKTHROUGH' as ActiveTab,
              title: '🎬 Four-stage Live Pitch Runner',
              desc: 'Step-by-step pilot pitch sequence: Farmer WhatsApp → OR-Tools Map → UPI Payout → Satellite 0-Burn.',
              tag: 'Nirdhoom Flow',
              badgeColor: 'text-emerald-300 bg-emerald-950/60 border-emerald-500/30',
            },
            {
              tab: 'DIGITAL_TWIN_3D' as ActiveTab,
              title: '🌐 3D Geospatial Digital Twin',
              desc: 'Three.js interactive Punjab Malwa hotspot with orbiting NOAA-20 satellite, radar scan cone, and fire plumes.',
              tag: 'Three.js 3D',
              badgeColor: 'text-emerald-400 bg-teal-950/60 border-teal-500/30',
            },
            {
              tab: 'MACHINERY_3D' as ActiveTab,
              title: '🚜 3D Subsidised Baler Twin',
              desc: 'Interactive CAD-style mechanical twin with rotating pickup reel, hydraulic flywheel, and moisture sensor probe.',
              tag: 'CRM Fleet',
              badgeColor: 'text-emerald-400 bg-cyan-950/60 border-cyan-500/30',
            },
            {
              tab: 'OPS_CONSOLE' as ActiveTab,
              title: '🗺️ Ops Console & OR-Tools VRP',
              desc: 'Live GIS mapping of Sangrur cluster with Google OR-Tools time-windowed vehicle routing and penalty bounds.',
              tag: 'Core Product',
              badgeColor: 'text-emerald-300 bg-emerald-950/60 border-emerald-500/30',
            },
            {
              tab: 'FARMER_SURFACE' as ActiveTab,
              title: '💬 Farmer WhatsApp & IVR Bot',
              desc: 'Bilingual Punjabi WhatsApp bot with missed-call-to-IVR flow, instant slot contract, and voice notes.',
              tag: 'Primary Surface',
              badgeColor: 'text-amber-300 bg-amber-950/60 border-amber-500/30',
            },
            {
              tab: 'BALER_OPERATOR' as ActiveTab,
              title: '📱 Field Operator Offline PWA',
              desc: 'Low-connectivity field app with IndexedDB sync queue, QR lot weighment, and instant UPI payout trigger.',
              tag: 'Offline-First',
              badgeColor: 'text-emerald-400 bg-blue-950/60 border-blue-500/30',
            },
            {
              tab: 'SATELLITE_AUDIT' as ActiveTab,
              title: '🛰️ NASA FIRMS 375m Audit',
              desc: 'Zero fire points inside registered customer polygons against neighboring firestorms. The Money Shot.',
              tag: 'The Defense',
              badgeColor: 'text-emerald-300 bg-emerald-950/60 border-emerald-500/30',
            },
            {
              tab: 'OFFTAKE_AUCTION' as ActiveTab,
              title: '🌾 Multi-Offtake Dynamic Auction',
              desc: 'Routing straw to mushroom substrate (₹3,200/T), Craste moulded fibre, biochar, and cattle feed.',
              tag: 'Wedge 5',
              badgeColor: 'text-emerald-400 bg-teal-950/60 border-teal-500/30',
            },
            {
              tab: 'CARBON_MARKET' as ActiveTab,
              title: '🌿 Carbon Credit Marketplace',
              desc: 'Institutional carbon credit issuance from satellite-verified non-burning records for CBG & registries.',
              tag: 'Outcome Credits',
              badgeColor: 'text-emerald-300 bg-emerald-950/60 border-emerald-500/30',
            },
            {
              tab: 'FARMER_ONBOARDING' as ActiveTab,
              title: '📍 Polygon Drawing & KYC',
              desc: 'Interactive field polygon drawing on satellite tiles with khasra number verification and variety selection.',
              tag: 'KYC & Demand',
              badgeColor: 'text-emerald-400 bg-cyan-950/60 border-cyan-500/30',
            },
            {
              tab: 'FAQ_ECONOMICS' as ActiveTab,
              title: '🛡️ Reviewer Defense & Unit Economics',
              desc: 'Direct cross-examination answers for Verbio comparison, in-situ alternatives, 10-month baler downtime, and margins.',
              tag: 'Q&A Prep',
              badgeColor: 'text-purple-300 bg-purple-950/60 border-purple-500/30',
            },
          ].map((item, idx) => (
            <div
              key={idx}
              onClick={() => onNavigateTab(item.tab)}
              className="p-4 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-emerald-500/50 hover:bg-slate-900/90 transition-all cursor-pointer flex flex-col justify-between group shadow-sm hover:shadow-emerald-500/10"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold uppercase border ${item.badgeColor}`}>
                    {item.tag}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all" />
                </div>
                <h4 className="text-sm font-bold text-white font-['Outfit'] group-hover:text-emerald-300 transition-colors">
                  {item.title}
                </h4>
                <p className="text-xs text-slate-400 mt-1 font-['Plus_Jakarta_Sans'] leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-emerald-400 font-semibold">
                <span>Open Surface</span>
                <span>&rarr;</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
