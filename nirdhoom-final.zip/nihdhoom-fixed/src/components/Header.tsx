import {
  Sparkles, Map, MessageSquare, Smartphone, Satellite, TrendingUp,
  HelpCircle, ShieldCheck, Zap, Box, Globe, Leaf, UserCheck, Bot,
  type LucideIcon,
} from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';

export type ActiveTab =
  | 'OVERVIEW' | 'AGENTIC_CONSOLE' | 'WALKTHROUGH' | 'DIGITAL_TWIN_3D'
  | 'MACHINERY_3D' | 'OPS_CONSOLE' | 'FARMER_SURFACE' | 'BALER_OPERATOR'
  | 'SATELLITE_AUDIT' | 'OFFTAKE_AUCTION' | 'CARBON_MARKET'
  | 'FARMER_ONBOARDING' | 'FAQ_ECONOMICS';

interface HeaderProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  openBrief: () => void;
}

type TabDef = { id: ActiveTab; label: string; icon: LucideIcon };

/**
 * The old header packed the logo, five stat chips and thirteen tabs into one
 * flex row roughly 55px tall. The rail ended up 573px wide holding 1173px of
 * tabs, so seven tabs ran off the viewport and could not be clicked, and the
 * whole thing read as noise.
 *
 * Two rows now. Identity and live state on top, a full-width grouped rail
 * below. One active treatment for every tab instead of six gradient schemes.
 */
const NAV: { group: string; tabs: TabDef[] }[] = [
  { group: 'Product', tabs: [
    { id: 'OVERVIEW', label: 'Overview', icon: Sparkles },
    { id: 'WALKTHROUGH', label: 'Walkthrough', icon: Zap },
    { id: 'FAQ_ECONOMICS', label: 'Q&A', icon: HelpCircle },
  ]},
  { group: 'Operate', tabs: [
    { id: 'AGENTIC_CONSOLE', label: 'Agent swarm', icon: Bot },
    { id: 'OPS_CONSOLE', label: 'Dispatch map', icon: Map },
    { id: 'FARMER_SURFACE', label: 'WhatsApp', icon: MessageSquare },
    { id: 'BALER_OPERATOR', label: 'Field app', icon: Smartphone },
    { id: 'FARMER_ONBOARDING', label: 'Onboarding', icon: UserCheck },
  ]},
  { group: 'Prove', tabs: [
    { id: 'SATELLITE_AUDIT', label: 'Verification', icon: Satellite },
    { id: 'OFFTAKE_AUCTION', label: 'Auction', icon: TrendingUp },
    { id: 'CARBON_MARKET', label: 'Carbon market', icon: Leaf },
  ]},
  { group: 'Twin', tabs: [
    { id: 'DIGITAL_TWIN_3D', label: 'Digital twin', icon: Globe },
    { id: 'MACHINERY_3D', label: 'Baler model', icon: Box },
  ]},
];

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, openBrief }) => (
  <header
    className="nrd-header sticky top-0 backdrop-blur-xl"
    style={{ background: 'var(--nav-bg-solid)', borderBottom: '1px solid var(--line)' }}
  >
    {/* Row 1 */}
    <div className="mx-auto flex max-w-[1340px] items-center gap-3 px-4 py-3 sm:px-6">
      <button
        onClick={() => setActiveTab('OVERVIEW')}
        className="flex shrink-0 cursor-pointer items-center gap-3 text-left"
        aria-label="Go to overview"
      >
        <span
          className="flex h-10 w-10 items-center justify-center text-xl font-bold"
          style={{
            background: 'var(--blue-deep)',
            border: '1px solid var(--line-strong)',
            borderRadius: 'var(--radius-sm)',
            color: 'var(--blue-bright)',
            fontFamily: 'var(--font-body)',
          }}
        >
          ਨਿ
        </span>
        <span className="leading-tight">
          <span
            className="block text-[17px] font-bold tracking-tight"
            style={{ fontFamily: 'var(--font-head)', color: 'var(--text)', letterSpacing: '-0.02em' }}
          >
            Nirdhoom
          </span>
          <span className="hidden text-[11.5px] sm:block" style={{ color: 'var(--muted-2)' }}>
            Sangrur cluster, Punjab
          </span>
        </span>
      </button>

      {/* Live state reads as instrumentation, not as five competing chips */}
      <div
        className="ml-auto hidden items-center gap-4 px-4 py-2 font-mono text-[11px] lg:flex"
        style={{
          border: '1px solid var(--line)',
          borderRadius: 'var(--radius-sm)',
          background: 'var(--panel-soft)',
          color: 'var(--muted)',
        }}
      >
        <span className="flex items-center gap-2" style={{ color: 'var(--blue-bright)' }}>
          <span className="h-1.5 w-1.5 animate-pulse rounded-full" style={{ background: 'var(--blue-bright)' }} />
          Live
        </span>
        <Sep />
        <span>Idle CRM <b style={{ color: 'var(--text)', fontWeight: 600 }}>4 balers / 88 ac</b></span>
        <Sep />
        <span className="flex items-center gap-1.5">
          <ShieldCheck className="h-3.5 w-3.5" style={{ color: 'var(--blue-bright)' }} />
          VIIRS <b style={{ color: 'var(--blue-bright)', fontWeight: 600 }}>0 burns</b>
        </span>
        <Sep />
        <span style={{ color: 'var(--accent-amber)' }}>UPI under 90s</span>
      </div>

      <div className="ml-auto flex shrink-0 items-center gap-2 lg:ml-0">
        <button onClick={openBrief} className="btn-secondary flex cursor-pointer items-center gap-1.5 !py-2 !text-xs">
          <Sparkles className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Product brief</span>
        </button>
        <ThemeToggle />
      </div>
    </div>

    {/* Row 2: every tab reachable */}
    <div className="relative" style={{ borderTop: '1px solid var(--line)' }}>
      <div className="nav-rail mx-auto flex max-w-[1340px] items-center gap-1 overflow-x-auto px-4 py-2 sm:px-6">
        {NAV.map((section, i) => (
          <div key={section.group} className="flex shrink-0 items-center gap-1">
            {i > 0 && <span className="mx-2.5 h-4 w-px shrink-0" style={{ background: 'var(--line)' }} />}
            <span
              className="mr-1.5 hidden shrink-0 text-[10px] font-semibold tracking-wide 2xl:block"
              style={{ color: 'var(--muted-2)' }}
            >
              {section.group}
            </span>
            {section.tabs.map(({ id, label, icon: Icon }) => {
              const active = activeTab === id;
              return (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  aria-current={active ? 'page' : undefined}
                  className="flex shrink-0 cursor-pointer items-center gap-1.5 whitespace-nowrap px-3 py-1.5 text-[12.5px] font-semibold transition-colors"
                  style={{
                    borderRadius: 'var(--radius-xs)',
                    background: active ? 'var(--blue-bright)' : 'transparent',
                    color: active ? 'var(--on-accent)' : 'var(--muted)',
                  }}
                >
                  <Icon className="h-3.5 w-3.5" />
                  {label}
                </button>
              );
            })}
          </div>
        ))}
      </div>
      <span
        className="pointer-events-none absolute inset-y-0 right-0 w-10"
        style={{ background: 'linear-gradient(to left, var(--nav-bg-solid), transparent)' }}
      />
    </div>
  </header>
);

const Sep = () => <span style={{ color: 'var(--line)' }}>/</span>;
